// 📄 完整替换文件：Widgets/WidgetKorean.swift
import SwiftUI
import PhotosUI

final class KoreanWidgetPlugin: BaseWidgetPlugin {
    override class func register() {
        WidgetRegistry.shared.registerKoreanWidget()
    }
}

class KoreanMessageWidgetManager: ObservableObject {
    static let shared = KoreanMessageWidgetManager()
    
    private let photoIdKey = "App_Widget_Korean_ImageID"
    private let headerKey = "App_Widget_Korean_HeaderTitle"
    private let nameKey = "App_Widget_Korean_ProfileName"
    private let leftTextKey = "App_Widget_Korean_FirstLeftText"
    private let rightTextKey = "App_Widget_Korean_FirstRightText"
    private let secondTextKey = "App_Widget_Korean_SecondText"
    private let addedKey = "App_Widget_Korean_IsAdded"
    private let pageKey = "App_Widget_Korean_PagePosition"
    private let rowKey = "App_Widget_Korean_RowPosition"
    
    private let kTransparentKey = "App_Widget_Korean_IsTransparent"
    private let kBgColorKey = "App_Widget_Korean_BgColor"
    private let kBoxStyleKey = "App_Widget_Korean_BoxStyle"
    private let kPinPreviewKey = "App_Widget_Korean_IsPinPreview"
    
    private let kBoxBorderWidthKey = "App_Widget_Korean_BoxBorderWidth"
    private let kBoxBorderColorKey = "App_Widget_Korean_BoxBorderColor"
    
    private let kHeaderColorKey = "App_Widget_Korean_HeaderColor"
    private let kNameColorKey = "App_Widget_Korean_NameColor"
    private let kLeftColorKey = "App_Widget_Korean_LeftColor"
    private let kRightColorKey = "App_Widget_Korean_RightColor"
    private let kSecondColorKey = "App_Widget_Korean_SecondColor"
    private let kSealColorKey = "App_Widget_Korean_SealColor"
    
    private let kHeaderSizeKey = "App_Widget_Korean_HeaderSize"
    private let kNameSizeKey = "App_Widget_Korean_NameSize"
    private let kLeftSizeKey = "App_Widget_Korean_LeftSize"
    private let kRightSizeKey = "App_Widget_Korean_RightSize"
    private let kSecondSizeKey = "App_Widget_Korean_SecondSize"
    
    private let kHeaderWeightKey = "App_Widget_Korean_HeaderWeight"
    private let kNameWeightKey = "App_Widget_Korean_NameWeight"
    private let kLeftWeightKey = "App_Widget_Korean_LeftWeight"
    private let kRightWeightKey = "App_Widget_Korean_RightWeight"
    private let kSecondWeightKey = "App_Widget_Korean_SecondWeight"
    
    private let kAvatarSizeKey = "App_Widget_Korean_AvatarSize"
    private let kSealSizeKey = "App_Widget_Korean_SealSize"
    
    @Published var widgetImageData: Data? {
        didSet {
            let oldId = UserDefaults.standard.string(forKey: photoIdKey)
            LocalImageStore.shared.replace(oldId: oldId, with: widgetImageData) { newId in
                UserDefaults.standard.set(newId, forKey: self.photoIdKey)
            }
        }
    }
    
    @Published var headerTitle: String { didSet { UserDefaults.standard.set(headerTitle, forKey: headerKey) } }
    @Published var profileName: String { didSet { UserDefaults.standard.set(profileName, forKey: nameKey) } }
    @Published var firstBarLeftText: String { didSet { UserDefaults.standard.set(firstBarLeftText, forKey: leftTextKey) } }
    @Published var firstBarRightText: String { didSet { UserDefaults.standard.set(firstBarRightText, forKey: rightTextKey) } }
    @Published var secondBarText: String { didSet { UserDefaults.standard.set(secondBarText, forKey: secondTextKey) } }
    @Published var isAddedToDesktop: Bool { didSet { UserDefaults.standard.set(isAddedToDesktop, forKey: addedKey) } }
    @Published var widgetPage: Int { didSet { UserDefaults.standard.set(widgetPage, forKey: pageKey) } }
    @Published var widgetRow: Int { didSet { UserDefaults.standard.set(widgetRow, forKey: rowKey) } }
    @Published var isTransparentBackground: Bool { didSet { UserDefaults.standard.set(isTransparentBackground, forKey: kTransparentKey) } }
    @Published var backgroundColorHex: String { didSet { UserDefaults.standard.set(backgroundColorHex, forKey: kBgColorKey) } }
    @Published var boxStyle: String { didSet { UserDefaults.standard.set(boxStyle, forKey: kBoxStyleKey) } }
    @Published var isPinPreviewToTop: Bool { didSet { UserDefaults.standard.set(isPinPreviewToTop, forKey: kPinPreviewKey) } }
    
    @Published var boxBorderWidth: Double { didSet { UserDefaults.standard.set(boxBorderWidth, forKey: kBoxBorderWidthKey) } }
    @Published var boxBorderColorHex: String { didSet { UserDefaults.standard.set(boxBorderColorHex, forKey: kBoxBorderColorKey) } }
    
    @Published var headerColorHex: String { didSet { UserDefaults.standard.set(headerColorHex, forKey: kHeaderColorKey) } }
    @Published var nameColorHex: String { didSet { UserDefaults.standard.set(nameColorHex, forKey: kNameColorKey) } }
    @Published var leftColorHex: String { didSet { UserDefaults.standard.set(leftColorHex, forKey: kLeftColorKey) } }
    @Published var rightColorHex: String { didSet { UserDefaults.standard.set(rightColorHex, forKey: kRightColorKey) } }
    @Published var secondColorHex: String { didSet { UserDefaults.standard.set(secondColorHex, forKey: kSecondColorKey) } }
    @Published var sealColorHex: String { didSet { UserDefaults.standard.set(sealColorHex, forKey: kSealColorKey) } }
    
    @Published var headerSize: Double { didSet { UserDefaults.standard.set(headerSize, forKey: kHeaderSizeKey) } }
    @Published var nameSize: Double { didSet { UserDefaults.standard.set(nameSize, forKey: kNameSizeKey) } }
    @Published var leftSize: Double { didSet { UserDefaults.standard.set(leftSize, forKey: kLeftSizeKey) } }
    @Published var rightSize: Double { didSet { UserDefaults.standard.set(rightSize, forKey: kRightSizeKey) } }
    @Published var secondSize: Double { didSet { UserDefaults.standard.set(secondSize, forKey: kSecondSizeKey) } }
    
    @Published var headerWeightName: String { didSet { UserDefaults.standard.set(headerWeightName, forKey: kHeaderWeightKey) } }
    @Published var nameWeightName: String { didSet { UserDefaults.standard.set(nameWeightName, forKey: kNameWeightKey) } }
    @Published var leftWeightName: String { didSet { UserDefaults.standard.set(leftWeightName, forKey: kLeftWeightKey) } }
    @Published var rightWeightName: String { didSet { UserDefaults.standard.set(rightWeightName, forKey: kRightWeightKey) } }
    @Published var secondWeightName: String { didSet { UserDefaults.standard.set(secondWeightName, forKey: kSecondWeightKey) } }
    
    @Published var avatarSize: Double { didSet { UserDefaults.standard.set(avatarSize, forKey: kAvatarSizeKey) } }
    @Published var sealSize: Double { didSet { UserDefaults.standard.set(sealSize, forKey: kSealSizeKey) } }
    
    var backgroundColor: Color { Color(hex: backgroundColorHex) }
    var boxBorderColor: Color { Color(hex: boxBorderColorHex) }
    var headerColor: Color { Color(hex: headerColorHex) }
    var nameColor: Color { Color(hex: nameColorHex) }
    var leftColor: Color { Color(hex: leftColorHex) }
    var rightColor: Color { Color(hex: rightColorHex) }
    var secondColor: Color { Color(hex: secondColorHex) }
    var sealColor: Color { Color(hex: sealColorHex) }
    
    var headerWeight: Font.Weight { Font.Weight.from(name: headerWeightName) }
    var nameWeight: Font.Weight { Font.Weight.from(name: nameWeightName) }
    var leftWeight: Font.Weight { Font.Weight.from(name: leftWeightName) }
    var rightWeight: Font.Weight { Font.Weight.from(name: rightWeightName) }
    var secondWeight: Font.Weight { Font.Weight.from(name: secondWeightName) }
    
    init() {
        if let savedId = UserDefaults.standard.string(forKey: photoIdKey) {
            self.widgetImageData = LocalImageStore.shared.load(id: savedId)
        }
        
        self.headerTitle = UserDefaults.standard.string(forKey: headerKey) ?? "보내기 ♡"
        self.profileName = UserDefaults.standard.string(forKey: nameKey) ?? "디저트"
        self.firstBarLeftText = UserDefaults.standard.string(forKey: leftTextKey) ?? "고생 끝에 낙이 온다"
        self.firstBarRightText = UserDefaults.standard.string(forKey: rightTextKey) ?? "슬프다"
        self.secondBarText = UserDefaults.standard.string(forKey: secondTextKey) ?? "kunoouc"
        
        self.isAddedToDesktop = UserDefaults.standard.bool(forKey: addedKey)
        self.widgetPage = UserDefaults.standard.integer(forKey: pageKey)
        let rawRow = UserDefaults.standard.object(forKey: rowKey) != nil ? UserDefaults.standard.integer(forKey: rowKey) : 4
        self.widgetRow = min(max(0, rawRow), 4)
        
        self.isTransparentBackground = UserDefaults.standard.bool(forKey: kTransparentKey)
        self.backgroundColorHex = UserDefaults.standard.string(forKey: kBgColorKey) ?? "#EDEDF2"
        self.boxStyle = UserDefaults.standard.string(forKey: kBoxStyleKey) ?? "shadow"
        self.isPinPreviewToTop = UserDefaults.standard.object(forKey: kPinPreviewKey) != nil ? UserDefaults.standard.bool(forKey: kPinPreviewKey) : true
        
        self.boxBorderWidth = UserDefaults.standard.object(forKey: kBoxBorderWidthKey) != nil ? UserDefaults.standard.double(forKey: kBoxBorderWidthKey) : 0.9
        self.boxBorderColorHex = UserDefaults.standard.string(forKey: kBoxBorderColorKey) ?? "#E5E5EA"
        
        self.headerColorHex = UserDefaults.standard.string(forKey: kHeaderColorKey) ?? "#000000"
        self.nameColorHex = UserDefaults.standard.string(forKey: kNameColorKey) ?? "#000000"
        self.leftColorHex = UserDefaults.standard.string(forKey: kLeftColorKey) ?? "#000000"
        self.rightColorHex = UserDefaults.standard.string(forKey: kRightColorKey) ?? "#353A45"
        self.secondColorHex = UserDefaults.standard.string(forKey: kSecondColorKey) ?? "#000000"
        self.sealColorHex = UserDefaults.standard.string(forKey: kSealColorKey) ?? "#8E8E93"
        
        self.headerSize = UserDefaults.standard.object(forKey: kHeaderSizeKey) != nil ? UserDefaults.standard.double(forKey: kHeaderSizeKey) : 11
        self.nameSize = UserDefaults.standard.object(forKey: kNameSizeKey) != nil ? UserDefaults.standard.double(forKey: kNameSizeKey) : 11.5
        self.leftSize = UserDefaults.standard.object(forKey: kLeftSizeKey) != nil ? UserDefaults.standard.double(forKey: kLeftSizeKey) : 12.0
        self.rightSize = UserDefaults.standard.object(forKey: kRightSizeKey) != nil ? UserDefaults.standard.double(forKey: kRightSizeKey) : 11.0
        self.secondSize = UserDefaults.standard.object(forKey: kSecondSizeKey) != nil ? UserDefaults.standard.double(forKey: kSecondSizeKey) : 12.5
        
        self.headerWeightName = UserDefaults.standard.string(forKey: kHeaderWeightKey) ?? "bold"
        self.nameWeightName = UserDefaults.standard.string(forKey: kNameWeightKey) ?? "semibold"
        self.leftWeightName = UserDefaults.standard.string(forKey: kLeftWeightKey) ?? "regular"
        self.rightWeightName = UserDefaults.standard.string(forKey: kRightWeightKey) ?? "regular"
        self.secondWeightName = UserDefaults.standard.string(forKey: kSecondWeightKey) ?? "regular"
        
        self.avatarSize = UserDefaults.standard.object(forKey: kAvatarSizeKey) != nil ? UserDefaults.standard.double(forKey: kAvatarSizeKey) : 38.0
        self.sealSize = UserDefaults.standard.object(forKey: kSealSizeKey) != nil ? UserDefaults.standard.double(forKey: kSealSizeKey) : 22.0
        
        AutoTranslationManager.shared.prewarm(text: headerTitle)
        AutoTranslationManager.shared.prewarm(text: profileName)
        AutoTranslationManager.shared.prewarm(text: firstBarLeftText)
        AutoTranslationManager.shared.prewarm(text: firstBarRightText)
        AutoTranslationManager.shared.prewarm(text: secondBarText)
    }
}

struct KoreanMessageWidget4x2View: View {
    @ObservedObject var manager: KoreanMessageWidgetManager
    var showDashedBorder: Bool = false
    
    @State private var selectedPhotoItem: PhotosPickerItem? = nil
    @ObservedObject var translator = AutoTranslationManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    
    init(manager: KoreanMessageWidgetManager = .shared, showDashedBorder: Bool = false) {
        self.manager = manager
        self.showDashedBorder = showDashedBorder
    }
    
    private func effectiveWeight(_ customWeight: Font.Weight) -> Font.Weight {
        appearance.preferWidgetFontPriority ? customWeight : appearance.systemFontWeight
    }
    
    var body: some View {
        let s = uiScale // 🌟 注入全局放大系数
        
        GeometryReader { geo in
            let availableH = geo.size.height
            let isCompact = availableH <= (165.0 * s)
            let bar1H: CGFloat = isCompact ? (39.0 * s) : (44.0 * s)
            let bar2H: CGFloat = isCompact ? (34.0 * s) : (38.0 * s)
            let vSpacing: CGFloat = isCompact ? (6.0 * s) : (10.0 * s)
            
            ZStack(alignment: .topLeading) {
                Group {
                    if manager.isTransparentBackground { Color.clear } else { manager.backgroundColor }
                }
                .clipShape(RoundedRectangle(cornerRadius: 22 * s, style: .continuous))
                
                VStack(alignment: .leading, spacing: vSpacing) {
                    Text(translator.translate(manager.headerTitle))
                        .font(.system(size: CGFloat(manager.headerSize) * s))
                        .fontWeight(effectiveWeight(manager.headerWeight))
                        .foregroundColor(manager.headerColor)
                        .padding(.top, isCompact ? 0 : 2 * s)
                        .padding(.leading, 3 * s)
                    
                    HStack(spacing: 11 * s) {
                        PhotosPicker(selection: $selectedPhotoItem, matching: .images, photoLibrary: .shared()) {
                            Group {
                                if let data = manager.widgetImageData, let uiImage = ImageBitmapCache.shared.image(from: data) {
                                    Image(uiImage: uiImage).resizable().scaledToFill()
                                } else {
                                    ZStack {
                                        Color.white
                                        Image(systemName: "person.fill")
                                            .font(.system(size: CGFloat(manager.avatarSize * 0.45) * s))
                                            .foregroundColor(.secondary)
                                    }
                                }
                            }
                            .frame(width: CGFloat(manager.avatarSize) * s, height: CGFloat(manager.avatarSize) * s)
                            .clipShape(RoundedRectangle(cornerRadius: CGFloat(manager.avatarSize * 0.22) * s, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: CGFloat(manager.avatarSize * 0.22) * s, style: .continuous)
                                    .stroke(Color.primary.opacity(0.06), lineWidth: 0.8 * s)
                            )
                        }
                        .buttonStyle(.plain)
                        
                        Text(translator.translate(manager.profileName))
                            .font(.system(size: CGFloat(manager.nameSize) * s))
                            .fontWeight(effectiveWeight(manager.nameWeight))
                            .foregroundColor(manager.nameColor)
                        Spacer()
                        Image(systemName: "chevron.right")
                            .font(.system(size: 10 * s, weight: .medium))
                            .foregroundColor(.secondary.opacity(0.7))
                    }
                    .padding(.horizontal, 3 * s)
                    
                    HStack {
                        Text(translator.translate(manager.firstBarLeftText))
                            .font(.system(size: CGFloat(manager.leftSize) * s))
                            .fontWeight(effectiveWeight(manager.leftWeight))
                            .foregroundColor(manager.leftColor)
                        Spacer()
                        Text(translator.translate(manager.firstBarRightText))
                            .font(.system(size: CGFloat(manager.rightSize) * s))
                            .fontWeight(effectiveWeight(manager.rightWeight))
                            .foregroundColor(manager.rightColor)
                    }
                    .padding(.horizontal, 12 * s)
                    .frame(maxWidth: .infinity)
                    .frame(height: bar1H)
                    .background(Color.white)
                    .clipShape(RoundedRectangle(cornerRadius: 11 * s, style: .continuous))
                    .applyBoxStyle(style: manager.boxStyle, cornerRadius: 11 * s, borderWidth: manager.boxBorderWidth, borderColor: manager.boxBorderColor)
                    
                    HStack(spacing: 8 * s) {
                        HStack {
                            Text(translator.translate(manager.secondBarText))
                                .font(.system(size: CGFloat(manager.secondSize) * s))
                                .fontWeight(effectiveWeight(manager.secondWeight))
                                .foregroundColor(manager.secondColor)
                            Spacer()
                        }
                        .padding(.horizontal, 12 * s)
                        .frame(maxWidth: .infinity)
                        .frame(height: bar2H)
                        .background(Color.white)
                        .clipShape(RoundedRectangle(cornerRadius: 10 * s, style: .continuous))
                        .applyBoxStyle(style: manager.boxStyle, cornerRadius: 10 * s, borderWidth: manager.boxBorderWidth, borderColor: manager.boxBorderColor)
                        
                        ZStack {
                            Circle()
                                .stroke(manager.sealColor.opacity(0.55), lineWidth: 1.0 * s)
                                .frame(width: CGFloat(manager.sealSize) * s, height: CGFloat(manager.sealSize) * s)
                            Text("응")
                                .font(.system(size: CGFloat(manager.sealSize * 0.46) * s, weight: .bold))
                                .foregroundColor(manager.sealColor)
                        }
                        .padding(.trailing, 2 * s)
                    }
                    .frame(maxWidth: .infinity)
                }
                .padding(.horizontal, 12 * s)
                .padding(.vertical, isCompact ? 5.5 * s : 8.5 * s)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                
                RoundedRectangle(cornerRadius: 22 * s, style: .continuous)
                    .stroke(
                        manager.isTransparentBackground ? (showDashedBorder ? Color.secondary.opacity(0.4) : Color.clear) : Color.primary.opacity(0.08),
                        style: StrokeStyle(lineWidth: 1 * s, dash: (manager.isTransparentBackground && showDashedBorder) ? [5 * s, 4 * s] : [])
                    )
                    .allowsHitTesting(false)
            }
            .clipShape(RoundedRectangle(cornerRadius: 22 * s, style: .continuous))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .task(id: selectedPhotoItem) {
            if let data = try? await selectedPhotoItem?.loadTransferable(type: Data.self) {
                withAnimation(.easeInOut(duration: 0.25)) {
                    manager.widgetImageData = data
                }
                UINotificationFeedbackGenerator().notificationOccurred(.success)
            }
        }
    }
}

extension View {
    @ViewBuilder
    func applyBoxStyle(style: String, cornerRadius: CGFloat, borderWidth: Double = 0.9, borderColor: Color = Color.primary.opacity(0.12)) -> some View {
        let s = uiScale // 🌟 注入全局放大系数
        switch style {
        case "border":
            self.overlay(
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .stroke(borderColor, lineWidth: CGFloat(borderWidth) * s)
            )
        case "shadow":
            self.shadow(color: Color.black.opacity(0.035), radius: 2.5 * s, x: 0, y: 1.2 * s)
        default:
            self
        }
    }
}

extension WidgetRegistry {
    func registerKoreanWidget() {
        let mgr = KoreanMessageWidgetManager.shared
        let s = uiScale
        registerWidget(
            id: "korean",
            title: "widget_korean_title",
            subtitle: "sub_korean",
            badge: "4×2",
            manager: mgr,
            desktopView: {
                KoreanMessageWidget4x2View(manager: mgr)
            },
            previewView: {
                KoreanMessageWidget4x2View(manager: mgr).frame(height: 156 * s).padding(.horizontal, 16 * s)
            },
            editSheetView: { show in
                EditKoreanWidgetSheet(isPresented: show)
            }
        )
    }
}
