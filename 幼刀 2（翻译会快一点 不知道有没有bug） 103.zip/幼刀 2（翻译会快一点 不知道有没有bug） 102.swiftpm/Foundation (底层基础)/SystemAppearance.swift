import SwiftUI
import UIKit

// 📄 系统外观与显示设置管理
class SystemAppearance: ObservableObject {
    static let shared = SystemAppearance()
    
    // MARK: - 全局低饱和莫兰迪色系
    public static let morandiPresets: [String] = [
        "#8FA4B5", "#A3B8C8", "#A39BAE", "#B5ADC0",
        "#C8A8A8", "#D6BDBD", "#9EA3A8", "#B4B8BC"
    ]
    
    @Published var isAuto: Bool = true { didSet { UserDefaults.standard.set(isAuto, forKey: "App_isAutoTheme") } }
    @Published var isDark: Bool = true { didSet { UserDefaults.standard.set(isDark, forKey: "App_isDarkTheme") } }
    @Published var hideHomeIndicator: Bool = false { didSet { UserDefaults.standard.set(hideHomeIndicator, forKey: "App_hideHomeIndicator") } }
    @Published var hideStatusBar: Bool = false { didSet { UserDefaults.standard.set(hideStatusBar, forKey: "App_hideStatusBar") } }
    @Published var systemFontWeightName: String = "regular" { didSet { UserDefaults.standard.set(systemFontWeightName, forKey: "App_systemFontWeightName") } }
    @Published var preferWidgetFontPriority: Bool = true { didSet { UserDefaults.standard.set(preferWidgetFontPriority, forKey: "App_preferWidgetFontPriority") } }
    
    // 🌟 全局触感与震动开关
    @Published var enableHaptics: Bool = true {
        didSet { UserDefaults.standard.set(enableHaptics, forKey: "App_enableHaptics") }
    }
    
    // MARK: - 基础交互细节色彩
    @Published var sliderTrackColorHex: String = "#8FA4B5" { didSet { UserDefaults.standard.set(sliderTrackColorHex, forKey: "App_sliderTrackColorHex") } }
    @Published var toggleTintColorHex: String = "#8FA4B5" { didSet { UserDefaults.standard.set(toggleTintColorHex, forKey: "App_toggleTintColorHex") } }
    @Published var categoryTagColorHex: String = "#8FA4B5" { didSet { UserDefaults.standard.set(categoryTagColorHex, forKey: "App_categoryTagColorHex") } }
    @Published var accentTextColorHex: String = "#8FA4B5" { didSet { UserDefaults.standard.set(accentTextColorHex, forKey: "App_accentTextColorHex") } }
    @Published var tabBarSelectedColorHex: String = "#8FA4B5" { didSet { UserDefaults.standard.set(tabBarSelectedColorHex, forKey: "App_tabBarSelectedColorHex") } }
    
    // MARK: - 设置主页独立图标色彩
    @Published var settingsLanguageIconColorHex: String = "#8FA4B5" { didSet { UserDefaults.standard.set(settingsLanguageIconColorHex, forKey: "App_settingsLangIconHex") } }
    @Published var settingsAppearanceIconColorHex: String = "#A39BAE" { didSet { UserDefaults.standard.set(settingsAppearanceIconColorHex, forKey: "App_settingsAppIconHex") } }
    @Published var settingsWallpaperIconColorHex: String = "#C8A8A8" { didSet { UserDefaults.standard.set(settingsWallpaperIconColorHex, forKey: "App_settingsWallIconHex") } }
    @Published var settingsApiIconColorHex: String = "#9EA3A8" { didSet { UserDefaults.standard.set(settingsApiIconColorHex, forKey: "App_settingsApiIconHex") } }
    
    var sliderTrackColor: Color { Color(hex: sliderTrackColorHex) }
    var toggleTintColor: Color { Color(hex: toggleTintColorHex) }
    var categoryTagColor: Color { Color(hex: categoryTagColorHex) }
    var accentTextColor: Color { Color(hex: accentTextColorHex) }
    var tabBarSelectedColor: Color { Color(hex: tabBarSelectedColorHex) }
    
    var settingsLanguageIconColor: Color { Color(hex: settingsLanguageIconColorHex) }
    var settingsAppearanceIconColor: Color { Color(hex: settingsAppearanceIconColorHex) }
    var settingsWallpaperIconColor: Color { Color(hex: settingsWallpaperIconColorHex) }
    var settingsApiIconColor: Color { Color(hex: settingsApiIconColorHex) }
    
    var systemFontWeight: Font.Weight { Font.Weight.from(name: systemFontWeightName) }
    
    init() {
        if let autoVal = UserDefaults.standard.object(forKey: "App_isAutoTheme") as? Bool { self.isAuto = autoVal }
        if let darkVal = UserDefaults.standard.object(forKey: "App_isDarkTheme") as? Bool { self.isDark = darkVal }
        if let indicatorVal = UserDefaults.standard.object(forKey: "App_hideHomeIndicator") as? Bool { self.hideHomeIndicator = indicatorVal }
        if let statusVal = UserDefaults.standard.object(forKey: "App_hideStatusBar") as? Bool { self.hideStatusBar = statusVal }
        if let fontVal = UserDefaults.standard.string(forKey: "App_systemFontWeightName") { self.systemFontWeightName = fontVal }
        if let widgetPriorityVal = UserDefaults.standard.object(forKey: "App_preferWidgetFontPriority") as? Bool { self.preferWidgetFontPriority = widgetPriorityVal }
        
        if let hapticsVal = UserDefaults.standard.object(forKey: "App_enableHaptics") as? Bool { self.enableHaptics = hapticsVal }
        
        if let sHex = UserDefaults.standard.string(forKey: "App_sliderTrackColorHex") { self.sliderTrackColorHex = sHex }
        if let tHex = UserDefaults.standard.string(forKey: "App_toggleTintColorHex") { self.toggleTintColorHex = tHex }
        if let cHex = UserDefaults.standard.string(forKey: "App_categoryTagColorHex") { self.categoryTagColorHex = cHex }
        if let aHex = UserDefaults.standard.string(forKey: "App_accentTextColorHex") { self.accentTextColorHex = aHex }
        if let tbHex = UserDefaults.standard.string(forKey: "App_tabBarSelectedColorHex") { self.tabBarSelectedColorHex = tbHex }
        
        if let lHex = UserDefaults.standard.string(forKey: "App_settingsLangIconHex") { self.settingsLanguageIconColorHex = lHex }
        if let apHex = UserDefaults.standard.string(forKey: "App_settingsAppIconHex") { self.settingsAppearanceIconColorHex = apHex }
        if let wHex = UserDefaults.standard.string(forKey: "App_settingsWallIconHex") { self.settingsWallpaperIconColorHex = wHex }
        if let apiHex = UserDefaults.standard.string(forKey: "App_settingsApiIconHex") { self.settingsApiIconColorHex = apiHex }
    }
    
    var colorScheme: ColorScheme? {
        if isAuto { return nil }
        return isDark ? .dark : .light
    }
}

// 🌟 全局统一安全触觉震动分发器（受 enableHaptics 开关拦截）
public struct AppHaptic {
    public static func impact(_ style: UIImpactFeedbackGenerator.FeedbackStyle = .medium) {
        guard SystemAppearance.shared.enableHaptics else { return }
        UIImpactFeedbackGenerator(style: style).impactOccurred()
    }
    
    public static func notify(_ type: UINotificationFeedbackGenerator.FeedbackType) {
        guard SystemAppearance.shared.enableHaptics else { return }
        UINotificationFeedbackGenerator().notificationOccurred(type)
    }
}

extension View {
    @ViewBuilder
    func applyCustomAppearance(_ appearance: SystemAppearance) -> some View {
        if !appearance.isAuto {
            self
                .tint(appearance.accentTextColor)
                .environment(\.colorScheme, appearance.isDark ? .dark : .light)
        } else {
            self
                .tint(appearance.accentTextColor)
        }
    }
}
