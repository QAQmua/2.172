import SwiftUI

// MARK: - 1. 微信冷启动欢迎页
struct WeChatAuthRootView: View {
    @Binding var show: Bool
    @Binding var isLoggedIn: Bool
    @ObservedObject var appearance = SystemAppearance.shared 
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Spacer()
                
                Image(systemName: "message.fill")
                    .font(.system(size: 80))
                    .foregroundColor(Color(hex: "#07C160"))
                    .padding(.bottom, 30)
                
                Spacer()
                
                HStack(spacing: 16) {
                    NavigationLink(destination: WeChatLoginView(isLoggedIn: $isLoggedIn)) {
                        Text("登录".tr)
                            .font(.system(size: 16, weight: .medium))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(Color(UIColor.secondarySystemFill))
                            .foregroundColor(Color(hex: "#07C160"))
                            .cornerRadius(8)
                    }
                    
                    NavigationLink(destination: WeChatRegisterView(isLoggedIn: $isLoggedIn)) {
                        Text("注册".tr)
                            .font(.system(size: 16, weight: .medium))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(Color(hex: "#07C160"))
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 50)
            }
            .navigationBarHidden(true)
            .background(Color(UIColor.systemBackground))
        }
    }
}

// MARK: - 2. 登录页面
struct WeChatLoginView: View {
    @Binding var isLoggedIn: Bool
    @Environment(\.dismiss) var dismiss
    
    @State private var phoneNumber: String = ""
    @State private var isAgreed: Bool = false
    @State private var showWarning: Bool = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("微信号/QQ/邮箱登录".tr)
                .font(.system(size: 22, weight: .regular))
                .padding(.top, 40)
                .padding(.horizontal, 24)
                .padding(.bottom, 40)
            
            VStack(spacing: 0) {
                HStack {
                    Text("账号".tr)
                        .frame(width: 80, alignment: .leading)
                        .font(.system(size: 16))
                    TextField("微信号/QQ号/邮箱".tr, text: $phoneNumber)
                        .font(.system(size: 16))
                        .textInputAutocapitalization(.never)
                }
                .padding(.vertical, 16)
                .overlay(Divider(), alignment: .bottom)
                
                HStack {
                    Text("密码".tr)
                        .frame(width: 80, alignment: .leading)
                        .font(.system(size: 16))
                    SecureField("请填写密码".tr, text: .constant(""))
                        .font(.system(size: 16))
                }
                .padding(.vertical, 16)
                .overlay(Divider(), alignment: .bottom)
            }
            .padding(.horizontal, 24)
            
            Text("用手机号登录".tr)
                .font(.system(size: 14))
                .foregroundColor(Color(hex: "#576B95"))
                .padding(.horizontal, 24)
                .padding(.top, 16)
            
            Spacer()
            
            HStack(alignment: .top, spacing: 8) {
                Button(action: { isAgreed.toggle(); showWarning = false }) {
                    Image(systemName: isAgreed ? "checkmark.circle.fill" : "circle")
                        .foregroundColor(isAgreed ? Color(hex: "#07C160") : .gray)
                        .font(.system(size: 18))
                }
                Text("已阅读并同意《软件许可及服务协议》".tr)
                    .font(.system(size: 12))
                    .foregroundColor(.gray)
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 16)
            
            if showWarning {
                Text("请先阅读并勾选协议".tr)
                    .font(.system(size: 12))
                    .foregroundColor(.red)
                    .padding(.horizontal, 50)
                    .padding(.bottom, 10)
            }
            
            Button(action: {
                if isAgreed {
                    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    withAnimation(.easeInOut(duration: 0.3)) { isLoggedIn = true }
                } else {
                    showWarning = true
                    UINotificationFeedbackGenerator().notificationOccurred(.error)
                }
            }) {
                Text("同意并登录".tr)
                    .font(.system(size: 16, weight: .medium))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(!phoneNumber.isEmpty ? Color(hex: "#07C160") : Color(hex: "#07C160").opacity(0.4))
                    .foregroundColor(phoneNumber.isEmpty ? .white.opacity(0.6) : .white)
                    .cornerRadius(8)
            }
            .disabled(phoneNumber.isEmpty)
            .padding(.horizontal, 24)
            .padding(.bottom, 40)
        }
        .navigationBarBackButtonHidden(true)
    }
}

// MARK: - 3. 注册页面
struct WeChatRegisterView: View {
    @Binding var isLoggedIn: Bool
    @Environment(\.dismiss) var dismiss
    
    @State private var nickname: String = ""
    @State private var phoneNumber: String = ""
    @State private var password: String = ""
    @State private var isAgreed: Bool = false
    @State private var showWarning: Bool = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("用手机号注册".tr)
                .font(.system(size: 22, weight: .regular))
                .padding(.top, 20)
                .padding(.horizontal, 24)
                .padding(.bottom, 30)
            
            HStack {
                Spacer()
                ZStack {
                    RoundedRectangle(cornerRadius: 12).fill(Color(UIColor.secondarySystemFill)).frame(width: 70, height: 70)
                    Image(systemName: "camera.fill").foregroundColor(.gray).font(.system(size: 24))
                }
                Spacer()
            }
            .padding(.bottom, 30)
            
            VStack(spacing: 0) {
                HStack {
                    Text("昵称".tr).frame(width: 80, alignment: .leading).font(.system(size: 16))
                    TextField("例如：陈晨".tr, text: $nickname).font(.system(size: 16))
                }
                .padding(.vertical, 16).overlay(Divider(), alignment: .bottom)
                
                HStack {
                    Text("国家/地区".tr).frame(width: 80, alignment: .leading).font(.system(size: 16))
                    Text("中国大陆 (+86)".tr).foregroundColor(Color(hex: "#07C160")).font(.system(size: 16))
                    Spacer()
                }
                .padding(.vertical, 16).overlay(Divider(), alignment: .bottom)
                
                HStack {
                    Text("手机号".tr).frame(width: 80, alignment: .leading).font(.system(size: 16))
                    TextField("请填写手机号".tr, text: $phoneNumber).keyboardType(.numberPad).font(.system(size: 16))
                }
                .padding(.vertical, 16).overlay(Divider(), alignment: .bottom)
                
                HStack {
                    Text("密码".tr).frame(width: 80, alignment: .leading).font(.system(size: 16))
                    SecureField("填写密码".tr, text: $password).font(.system(size: 16))
                }
                .padding(.vertical, 16).overlay(Divider(), alignment: .bottom)
            }
            .padding(.horizontal, 24)
            
            Spacer()
            
            HStack(alignment: .top, spacing: 8) {
                Button(action: { isAgreed.toggle(); showWarning = false }) {
                    Image(systemName: isAgreed ? "checkmark.circle.fill" : "circle")
                        .foregroundColor(isAgreed ? Color(hex: "#07C160") : .gray).font(.system(size: 18))
                }
                Text("我已阅读并同意《软件许可及服务协议》与《隐私政策》".tr)
                    .font(.system(size: 12)).foregroundColor(.gray).lineSpacing(4)
            }
            .padding(.horizontal, 24).padding(.bottom, 16)
            
            if showWarning {
                Text("请先阅读并勾选协议".tr).font(.system(size: 12)).foregroundColor(.red).padding(.horizontal, 50).padding(.bottom, 10)
            }
            
            NavigationLink(destination: WeChatVerificationView(phoneNumber: phoneNumber, isLoggedIn: $isLoggedIn)) {
                Text("同意并继续".tr)
                    .font(.system(size: 16, weight: .medium))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(isFormValid ? Color(hex: "#07C160") : Color(hex: "#07C160").opacity(0.4))
                    .foregroundColor(isFormValid ? .white : .white.opacity(0.6))
                    .cornerRadius(8)
            }
            .disabled(!isFormValid)
            .simultaneousGesture(TapGesture().onEnded {
                if !isAgreed { showWarning = true; UINotificationFeedbackGenerator().notificationOccurred(.error) }
            })
            .padding(.horizontal, 24)
            .padding(.bottom, 40)
        }
        .navigationBarBackButtonHidden(true)
    }
    
    private var isFormValid: Bool {
        return !phoneNumber.isEmpty && !password.isEmpty && !nickname.isEmpty
    }
}

// MARK: - 4. 验证码页面
struct WeChatVerificationView: View {
    var phoneNumber: String
    @Binding var isLoggedIn: Bool
    
    @State private var verifyCode: String = ""
    @State private var timeRemaining = 60
    @State private var timer: Timer?
    @State private var isVerifying = false
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("输入验证码".tr).font(.system(size: 24, weight: .regular)).padding(.top, 40)
            Text("验证码已发送至 +86 \(phoneNumber)".tr).font(.system(size: 14)).foregroundColor(.gray)
            
            HStack {
                TextField("请输入6位验证码".tr, text: $verifyCode)
                    .keyboardType(.numberPad)
                    .font(.system(size: 22, weight: .medium))
                    .onChange(of: verifyCode) { _, newValue in
                        if newValue.count > 6 { verifyCode = String(newValue.prefix(6)) }
                        if verifyCode.count == 6 { performVerification() }
                    }
                
                Spacer()
                
                if timeRemaining > 0 {
                    Text("\(timeRemaining)s").font(.system(size: 14)).foregroundColor(.gray)
                } else {
                    Button("重新获取".tr) {
                        timeRemaining = 60
                        startTimer()
                    }
                    .font(.system(size: 14)).foregroundColor(Color(hex: "#576B95"))
                }
            }
            .padding(.vertical, 15)
            .overlay(Divider(), alignment: .bottom)
            
            if isVerifying {
                HStack {
                    Spacer()
                    ProgressView().progressViewStyle(CircularProgressViewStyle(tint: Color(hex: "#07C160"))).padding(.top, 30)
                    Spacer()
                }
            }
            Spacer()
        }
        .padding(.horizontal, 24)
        .navigationBarBackButtonHidden(true)
        .onAppear {
            startTimer()
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                UINotificationFeedbackGenerator().notificationOccurred(.success)
            }
        }
        .onDisappear { timer?.invalidate() }
    }
    
    private func startTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            if timeRemaining > 0 { timeRemaining -= 1 } else { timer?.invalidate() }
        }
    }
    
    private func performVerification() {
        isVerifying = true
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            isVerifying = false
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
            withAnimation(.easeInOut(duration: 0.3)) { isLoggedIn = true }
        }
    }
}
