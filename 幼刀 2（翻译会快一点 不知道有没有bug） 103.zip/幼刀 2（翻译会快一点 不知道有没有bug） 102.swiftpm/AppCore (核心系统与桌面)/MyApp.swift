import SwiftUI

@main
struct MyApp: App {
    init() {
        // 🌟 启动全自动插件引擎（仅需这一行，全局激活）
        AppAutoEngine.boot()
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
